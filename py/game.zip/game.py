import pygame
import os

res_path = os.path.dirname(__file__) + "/dop/"


class Hulk():

    def __init__(self):
        self.walkright = [pygame.image.load(res_path + 'right1.png'),
                          pygame.image.load(res_path + 'right2.png'),
                          pygame.image.load(res_path + 'right3.png'),
                          pygame.image.load(res_path + 'right4.png'),
                          pygame.image.load(res_path + 'right5.png')]

        self.walkleft = [pygame.image.load(res_path + 'left1.png'),
                         pygame.image.load(res_path + 'left3.png'),
                         pygame.image.load(res_path + 'left4.png'),
                         pygame.image.load(res_path + 'left5.png')]

        self.jumppng = [pygame.image.load(res_path + 'jump2.png')]

        self.bg = pygame.image.load(res_path + 'backforest.jpg')
        self.playerstand = pygame.image.load(res_path + 'jump1.png')

        self.x = 200  # spawn
        self.y = 900  # spawn
        self.width = 117  # ширина фигуры
        self.height = 140  # высота фигуры
        self.speed = 7  # скорость
        self.jump = False  # прыжок
        self.jumpcount = 10  # высота прыжка
        self.left = False
        self.right = False
        self.animcount = 0


class Window():

    def __init__(self, hulk):
        self.xwin = 1280  # размер окна
        self.ywin = 1024  # размер окна
        self.win = pygame.display.set_mode((self.xwin, self.ywin))  # размер окна
        pygame.display.set_caption('HULK_TEST')  # имя окна

    def drawwindow(self, hulk):
        self.win.blit(hulk.bg, (0, 0))
        if hulk.animcount + 1 >= 30:
            hulk.animcount = 0
        if hulk.left:
            self.win.blit(
                hulk.walkleft[hulk.animcount // 6], (hulk.x, hulk.y))
            hulk.animcount += 1
        elif hulk.right:
            self.win.blit(
                hulk.walkright[hulk.animcount // 6], (hulk.x, hulk.y))
            hulk.animcount += 1
        elif hulk.jump:
            self.win.blit(
                hulk.jumppng[hulk.animcount // 30], (hulk.x, hulk.y))
        else:
            self.win.blit(hulk.playerstand, (hulk.x, hulk.y))

        pygame.display.update()


class Game():

    def __init__(self):
        pygame.init()
        self.clock = pygame.time.Clock()
        self.hulk = Hulk()
        self.window = Window(self.hulk)

    def run(self):
        run = True
        while run:
            self.clock.tick(30)
            pygame.time.delay(20)  # темп игры

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False
            keys = pygame.key.get_pressed()

            if keys[pygame.K_a] and self.hulk.x > 7:
                self.hulk.x -= self.hulk.speed
                self.hulk.left = True
                self.hulk.right = False
            elif keys[pygame.K_d] and self.hulk.x < self.window.xwin-self.hulk.width-7:
                self.hulk.x += self.hulk.speed
                self.hulk.left = False
                self.hulk.right = True
            else:
                self.hulk.left = False
                self.hulk.right = False
                self.hulk.animcount = 0
            if not(self.hulk.jump):
                if keys[pygame.K_w] and self.hulk.y > 250:
                    self.hulk.y -= self.hulk.speed
                if keys[pygame.K_s] and self.hulk.y < self.window.ywin-self.hulk.height-7:
                    self.hulk.y += self.hulk.speed
                if keys[pygame.K_SPACE] and self.hulk.y > 7 + self.hulk.jumpcount:
                    self.hulk.jump = True
            else:
                if self.hulk.jumpcount >= -10:
                    if self.hulk.jumpcount < 0:
                        self.hulk.y += (self.hulk.jumpcount**2) / 2
                    else:
                        self.hulk.y -= (self.hulk.jumpcount**2) / 2
                    self.hulk.jumpcount -= 1
                else:
                    self.hulk.jump = False
                    self.hulk.jumpcount = 10
            self.window.drawwindow(self.hulk)
        pygame.quit()


def main():
    game = Game()
    game.run()


main()
